import "./App.css";

function App() {
  return (
    <div className="App">
      {/* Write the message here. */}
      <p>Welcome to React Course on codingninjas.com</p>
    </div>
  );
}

export default App;
