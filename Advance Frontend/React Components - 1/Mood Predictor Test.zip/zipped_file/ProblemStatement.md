### Debug the React app to fix the binding issues

Objectives -

Clicking on the button should show the mood prediction.
