import { Component } from "react";

class Skills extends Component {
  render() {
    return (
      <ul>
        <li>HTML</li>
        <li>CSS</li>
        <li>JavaScript</li>
        <li>React</li>
        <li>Node</li>
      </ul>
    );
  }
}

export default Skills;
