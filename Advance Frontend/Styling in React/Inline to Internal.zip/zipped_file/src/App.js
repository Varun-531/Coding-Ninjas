import "./styles.css";
import styles from "./styles";

export default function App() {
  return (
    <div className="App">
      <form style={styles.form}>
        <h3 style={styles.heading}>Sign Up</h3>
        <input style={styles.input} placeholder="Username" />
        <input style={styles.input} placeholder="Email" />
        <input style={styles.input} placeholder="Password" />
        <div style={styles.buttonContainer}>
          <button style={styles.button}>Cancel</button>
          <button style={styles.button}>Login</button>
        </div>
      </form>
    </div>
  );
}
