const styles = {
  form: {
    width: "60%",
    margin: "50px auto",
    display: "flex",
    flexDirection: "column",
    gap: "20px",
  },
  heading: {
    fontSize: "2rem",
    letterSpacing: "2px",
  },
  input: {
    padding: "10px",
  },
  buttonContainer: {
    display: "flex",
    justifyContent: "center",
    gap: "20px",
  },
  button: {
    outline: "none",
    paddingBlock: "5px",
    width: "100px",
    backgroundColor: "red",
    color: "white",
    cursor: "pointer",
  },
};

export default styles;
