import React from "react";
import Image from "./Image";

export default class ImageList extends React.Component {
  shouldComponentUpdate(nextProps) {
    return nextProps.images.length !== this.props.images.length;
  }

  render() {
    return (
      <div className="image-list">
        {this.props.images.map((image, index) => {
          return <Image key={index} image={image} />;
        })}
      </div>
    );
  }
}
