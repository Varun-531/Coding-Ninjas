import React from "react";

// Complete this Component
const ListItem = ({ name, link, icon, bgColor }) => {
  return (
    <div
      className="ListItem"
      style={{
        backgroundColor: bgColor,
        padding: "10px",
        margin: "10px 0",
        borderRadius: "5px",
        display: "flex",
        alignItems: "center",
      }}
    >
      <img
        src={icon}
        alt={name}
        style={{ width: "30px", marginRight: "10px" }}
      />
      <a
        href={link}
        target="_blank"
        rel="noopener noreferrer"
        style={{ color: "black", textDecoration: "none" }}
      >
        {name}
      </a>
    </div>
  );
};

export default ListItem;
