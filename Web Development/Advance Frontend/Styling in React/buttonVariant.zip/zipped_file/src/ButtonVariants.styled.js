// src/reusable.styled.js
import styled from "styled-components";

export const ButtonView = styled.button`
  outline: none;
  border: ${(props) => (props.filled ? "none" : "2px solid #000")};
  cursor: pointer;
  margin: 10px;
  padding: 7px 15px;
  font-weight: bold;
  color: ${(props) => (props.filled ? props.color : "#000")};
  background-color: ${(props) => (props.filled ? props.bg : "transparent")};
  box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
`;
