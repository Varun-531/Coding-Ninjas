import React, { Component } from "react";
import Course from "./components/Course";
import { courses } from "./data"; // Ensure data.js is in src directory
import { Container } from "./reusable.styled"; // Updated import path

class List extends Component {
  render() {
    const { isCourseinBag, handleAdd, handleRemove } = this.props;
    return (
      <Container flex="3">
        {courses.map((v) => (
          <Course
            key={v.id}
            video={v}
            onAdd={handleAdd}
            onRemove={handleRemove}
            isInBag={isCourseinBag(v.id)}
          />
        ))}
      </Container>
    );
  }
}

export default List;
