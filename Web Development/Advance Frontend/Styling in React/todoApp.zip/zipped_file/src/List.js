// src/List.js
import { Component } from "react";
import { Todo } from "./Todo";

export class List extends Component {
  render() {
    return (
      <div className="list">
        {/* Render the todos passed as props */}
        {this.props.todos.map((todo, index) => (
          <Todo
            key={index}
            todo={todo}
            onRemove={() => this.props.handleRemove(index)}
          />
        ))}
      </div>
    );
  }
}
