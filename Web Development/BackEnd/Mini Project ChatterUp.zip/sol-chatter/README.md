# chatterup
 The aim of the ChatterUp project is to create an interactive real-time chat application, facilitating seamless communication and interaction between users. This application will be built using Node.js, ExpressJS, Socket.io, and MongoDB to provide a robust and engaging chat experience.
