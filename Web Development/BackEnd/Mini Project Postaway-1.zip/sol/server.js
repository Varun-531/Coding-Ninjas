import express from "express";
import bodyParser from "body-parser";
import userRouter from './src/features/user/user.route.js';
import postRouter from './src/features/posts/post.route.js';
import commentRouter from './src/features/comments/comments.route.js';
import jwtAuth from './src/middlewares/jwt.middleware.js'
const server = express();

server.use(bodyParser.json())


server.use("/api/posts",jwtAuth,postRouter);
server.use("/api/comment",jwtAuth,commentRouter);
server.use("/api/users",userRouter);
server.get("/" ,(req,res)=>{
    res.send("This is Social Media Platform.");
})


server.use(express.static('src'));
server.use(express.static('public'));
server.listen(4400);
console.log('Server is listening on port 4400');