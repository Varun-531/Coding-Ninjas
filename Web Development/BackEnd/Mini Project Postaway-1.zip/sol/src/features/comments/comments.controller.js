import CommentModel from "./comments.model.js";

export class CommentController {
    add(req, res) {
        const { userID ,productID, comment } = req.body;
        CommentModel.add(productID, userID, comment);
        res.status(201).send("Comment is added");
    }

    getbypost(req,res){
        const pid = req.params.id;
        console.log(pid)
        const result =CommentModel.getbyProductid(pid);
        console.log(result);
        res.status(200).send(result);
    }
}