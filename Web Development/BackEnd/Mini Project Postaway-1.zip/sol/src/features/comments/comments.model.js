

// postID, userID, comment
export default class CommentModel{
    constructor(id,postID, userID, comment){
        this.id = id;
        this.postID = postID;
        this.userID = userID;
        this.comment = comment;
    }

    static add(postID, userID, comment) {
        const newcomment = new CartItemModel(
            comments.length+1,
            postID,
            userID, 
            comment
            );
            comments.push(newcomment);
    }
    static getbyUserid(userID){
        return comments.filter(
            (i)=> i.userID == userID
        );
    }
    static getbyProductid(pid){
        return comments.filter((p) => p.postID == pid);
    }
}

var comments = [new CommentModel(1,1,1,"Product is good"),
            new CommentModel(2,1,2,"Product is marvelous"),
            new CommentModel(3,2,1,"Product is nice"),
            new CommentModel(4,2,2,"product is well")];