// Manage routes/paths to ProductController

// 1. Import express.
import express from 'express';
import { CommentController } from './comments.controller.js';


// 2. Initialize Express router.
const commentRouter = express.Router();

const commentController = new CommentController();

commentRouter.post('/add', commentController.add);
commentRouter.get("/getbypost/:id",commentController.getbypost);

export default commentRouter;