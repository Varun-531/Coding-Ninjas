import PostModel from './post.model.js';

export default class PostController{
    getAllPosts(req,res){
        const posts= PostModel.getAll();
        res.status(200).send(posts);
    }
    
    addPosts(req,res){
        const {userid,text}=req.body;
        const useridnum = parseInt(userid, 10);
        const imageUrl ='images'+ req.file.filename;
        PostModel.addPost(useridnum,text,imageUrl);
        const posts=PostModel.getAll();
        console.log(posts);
        res.status(201).send(posts)
    }

    removePost(req,res){
        const uid=req.query.uid;
        const poid =req.query.poid;
        PostModel.delete(uid,poid);
        const posts=PostModel.getAll();
        console.log(posts);
        res.status(200).send(posts)
    }
    

    getFilterPosts(req,res){
        const caption =req.params.caption;
        const useridnum = parseInt(caption, 10);
        const result =PostModel.filter(useridnum);
        res.status(200).send(result);
    }
}