import UserModel from '../user/user.model.js'




export default class PostModel{
    constructor(pid,userid,ptext,imageUrl){
        this.pid=pid;
        this.userid=userid;
        this.ptext=ptext;
        this.imageUrl=imageUrl;
    }

    static getAll(){
        return posts;
    }
    static addPost(userid,text,imageUrl){
        let newPost= new PostModel(
            posts.length+1,
            userid,
            text,
            imageUrl
        );

        posts.push(newPost)
    }
    static getbyId(id){
        return posts.find((p) => p.pid == id);
    }

    static delete(uid,poid){
        const index = posts.findIndex((p)=> (p.pid ==poid )&& (p.userid==uid));
        posts.splice(index,1);
    }

    static filter(caption){
        const result = posts.filter((post) =>{
            return(post.userid == caption);
        })
        return result;
    }
}

var posts = [
    new PostModel(
        1,
        1,
        "post-1 from teja",
        'https://m.media-amazon.com/images/I/51-nXsSRfZL._SX328_BO1,204,203,200_.jpg'
    ),
    new PostModel(
        2,
        1,
        "post-2 from teja",
        'https://m.media-amazon.com/images/I/51xwGSNX-EL._SX356_BO1,204,203,200_.jpg'
    ),
    new PostModel(
        3,
        2,
        "post-1 from ravi",
        "https://m.media-amazon.com/images/I/31PBdo581fL._SX317_BO1,204,203,200_.jpg"
    )

]