// Manage routes/paths to ProductController

// 1. Import express.
import express from 'express';
import PostController from './post.controller.js';
import {fileupload} from '../../middlewares/fileupload.middleware.js';

// 2. Initialize Express router.
const postRouter = express.Router();
const postController = new PostController();

// All the paths to the controller methods.
// localhost/api/posts
postRouter.get('/', postController.getAllPosts);
postRouter.post('/add', fileupload.single('imageUrl'),postController.addPosts);
postRouter.get("/remove/:id",postController.removePost);
postRouter.get('/filter/:caption',postController.getFilterPosts);


export default postRouter;