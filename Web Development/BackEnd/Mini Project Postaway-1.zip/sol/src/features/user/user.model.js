export default class UserModel {
    constructor(id,name, email, password) {
        this.id = id;
      this.name = name;
      this.email = email;
      this.password = password;
    }
  
    static SignUp(name, email, password) {
      const newUser = new UserModel(
        users.length + 1,
        name,
        email,
        password,
      );
      users.push(newUser);
      return newUser;
    }
  
    static SignIn(email, password) {
      const user = users.find(
        (u) =>
          u.email == email && u.password == password
      );
      return user;
    }
    static getAll(){
        return users;
      }
  }
  
  var users = [
    {
      id: 1,
      name: 'teja',
      email: 'teja123@gmail.com',
      password: 'pass'
    },
    {
      id: 2,
      name: 'ravi',
      email: 'ravi123@gmail.com',
      password: 'pass',
    }
  ];
  