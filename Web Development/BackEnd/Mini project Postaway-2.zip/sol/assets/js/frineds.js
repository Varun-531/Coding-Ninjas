let addFrndBtn = document.querySelectorAll("#addFrndBtn")
// addFrndBtn.forEach( (elem)=> {
//     console.log(elem.getAttribute("userID"));
//     console.log(`local user id ==> ${elem.getAttribute("localUserID")}`)
// });
// addFrndBtn.addEventListener("click", (element)=>{
//     console.log(element);
// })