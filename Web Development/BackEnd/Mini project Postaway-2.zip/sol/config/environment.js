const fs = require('fs');
// const rfs = require('rotating-file-stream');
const rfs = require("rotating-file-stream");
const path = require('path');

const logDirectory = path.join(__dirname, '../production_logs');
fs.existsSync(logDirectory) || fs.mkdirSync(logDirectory);

const accessLogStream = rfs.createStream('access.log', {
    interval: '1d',
    path: logDirectory,
});

const development = {
    name: 'development',
    port: 8000,
    chatserver_port: 5000,
    asset_path: './assets',
    session_cookie_key: 'blahsomething',
    db:'codeial_development',
    smtp: {
        service: 'zohomail',
        host: 'smtp.zoho.in',
        port: 587,
        secure: false,
        auth: {
            user: 'souvikhazra@zohomail.in',
            pass: 'Souvik123#@'
        }
    },
    google_client_id: "803960775872-8o0n3d6k42n9anvjuvc1e023rr1b6q51.apps.googleusercontent.com",
    google_client_secret: "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",
    google_callback_URL: "http://localhost:8000/users/auth/google/callback",
    jwt_secret: "codeial",
    morgan: {
        mode:'dev',
        options: {stream: accessLogStream}
    }
}

const production = {
    name: process.env.NODE_ENV,
    port: process.env.CODEIAL_PORT,
    chatserver_port: process.env.CODEIAL_CHATSERVER_PORT,
    asset_path: process.env.CODEIAL_ASSET_PATH,
    session_cookie_key: process.env.CODEIAL_SESSION_COOKIE,
    db: process.env.CODEIAL_DB,
    smtp: {
        service: 'zohomail',
        host: 'smtp.zoho.in',
        port: 587,
        secure: false,
        auth: {
            user: process.env.CODEIAL_ZOHOMAIL_USERNAME,
            pass: process.env.CODEIAL_ZOHOMAIL_PASSWORD,
        },
    },
    google_client_id: process.env.CODEIAL_GOOGLE_CLIENT_ID,
    google_client_secret: process.env.CODEIAL_GOOGLE_CLIENT_SECRET,
    google_callback_URL: process.env.CODEIAL_GOOGLE_CLIENT_CALLBACK_URL,
    jwt_secret: process.env.CODEIAL_JWT_SECRET,
    morgan: {
        mode:'combined',
        options: {stream: accessLogStream}
    }
}
console.log(process.env.NODE_ENV);
module.exports = eval((process.env.NODE_ENV) == undefined ? development : eval(process.env.NODE_ENV));
// module.exports=development;